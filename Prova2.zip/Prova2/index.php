<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fluxo de Caixa</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <h1>Fluxo de Caixa</h1>
    <div id="menu">
        <ul>
            <li><a href="cadastro_fluxo_caixa.html">Cadastro Fluxo de Caixa</a></li>
            <li><a href="listar_fluxo_caixa.php">Listagem de Fluxo de Caixa</a></li>
            <li><a href="consulta_fluxo_caixa.html">Consulta Saldo do Caixa</a></li>
        </ul>
    </div>
</body>
</html>